
# Monika's Rasoi — Minimal GitHub Pages Setup

This repo deploys a Vite + React app to **GitHub Pages**:
`https://vikas-pandey1507.github.io/monikas-rasoi/`

## Use (no local Node needed)
1. Create a public repo named **monikas-rasoi** under your account.
2. Upload all files from this zip to that repo (drag & drop on GitHub).
3. Go to **Settings → Pages** and set **Source = GitHub Actions**.
4. Open the **Actions** tab and wait for the workflow to finish.
5. Visit: `https://vikas-pandey1507.github.io/monikas-rasoi/`

## Local dev (optional)
```bash
npm install
npm run dev
```
