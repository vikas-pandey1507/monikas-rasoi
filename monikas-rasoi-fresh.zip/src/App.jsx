
export default function App(){
  return (
    <main style={{fontFamily:'system-ui, Arial', padding:'24px', lineHeight:1.5}}>
      <h1>Monika's Rasoi</h1>
      <p>Fresh vegetarian meals in Lucknow. Daily 08:00–20:00 IST.</p>
      <ul>
        <li><strong>Order WhatsApp:</strong> <a href="https://wa.me/918287306197" target="_blank" rel="noreferrer">+91 82873 06197</a></li>
        <li><strong>Email:</strong> <a href="mailto:vikaspandey092015@gmail.com">vikaspandey092015@gmail.com</a></li>
        <li><strong>Address:</strong> Ashraf Vihar Colony, Malhaur, Lucknow 226028</li>
      </ul>
      <hr style={{margin:'24px 0'}} />
      <p>If you can see this page on GitHub Pages, the deploy worked 🎉</p>
    </main>
  )
}
